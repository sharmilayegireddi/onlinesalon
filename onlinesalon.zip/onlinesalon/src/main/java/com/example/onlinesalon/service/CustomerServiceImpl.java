package com.example.onlinesalon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.onlinesalon.exceptions.CustomerException;
import com.example.onlinesalon.model.Customer;
import com.example.onlinesalon.repo.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired 
	private CustomerRepo customerRepo;
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepo.findAll();
	}

	@Override
	public Customer getCustomerById(String id) throws CustomerException {
		//Optional<Customer> optCust = this.customerRepo.findById(id);
	 java.util.Optional<Customer> optCust = this.customerRepo.findById(id);
		
		if(optCust.isEmpty())
			throw new CustomerException("Customerid Does not exists.");
		
		return optCust.get();
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return this.customerRepo.save(customer);
	}

	@Override
	public Customer deleteCustomerById(String Id) throws CustomerException {
		// TODO Auto-generated method stub
		 java.util.Optional<Customer> optcus = this.customerRepo.findById(Id);
		if(optcus.isEmpty())
			throw new CustomerException("Customer is not avaible to delete.");
		
		return optcus.get();
	}

	@Override
	public Customer AddCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return this.customerRepo.save(customer);
	}

	@Override
	public Customer createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

}

