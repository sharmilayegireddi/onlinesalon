package com.example.onlinesalon.service;

import java.util.List;

import com.example.onlinesalon.exceptions.CustomerException;
import com.example.onlinesalon.model.Customer;

public interface CustomerService {
	
	List<Customer> getAllCustomers();// get all records

	Customer createCustomer(Customer customer);// Create

	Customer getCustomerById(String id)throws CustomerException;// Read
	
	Customer updateCustomer(Customer customer);// Update

	Customer deleteCustomerById(String Id) throws CustomerException;// Delete

	Customer AddCustomer(Customer customer);//add customer
}
