package com.example.onlinesalon.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.data.mongodb.core.mapping.Document;

import nonapi.io.github.classgraph.json.Id;

@Document
public class Customer {
	@Id
     String customerId;
     
	@NotBlank(message = "Name can't be Blank.")
     String customerName;
	@Email(message = "Please enter valid Email eg: yourname@ipru.com.")
	 String emailId;
	@Pattern(regexp = "[a-zA-Z0-9]{8,}",message = "At least 8 characters,only uppercase lowercase and digits allowed.")
	String customerPassword;
    Long mobileNumber;
   Address address;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(
		 String customerId,
			 String customerName,
		    String emailId,
			 String customerPassword,
			Long mobileNumber, Address address) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.emailId = emailId;
		this.customerPassword = customerPassword;
		this.mobileNumber = mobileNumber;
		this.address = address;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}


}

