package com.example.onlinesalon.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.onlinesalon.exceptions.CustomerException;
import com.example.onlinesalon.model.Customer;
import com.example.onlinesalon.service.CustomerService;
//
//http://localhost:8080/swagger-ui/index.html

@CrossOrigin(value = "http://localhost:3000/")
@RestController
@RequestMapping("api")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	
	/*@GetMapping("customer") // RestFul api URL /employees HTTP:GET
	public List<Customer> getAllCustomers(){		
		
		return this.customerService.getAllCustomers();
	}*/
	
	@GetMapping("customers")
	public List<Customer> getAllCustomers() {
		return this.customerService.getAllCustomers();
	
	}
	
	@PostMapping("addcustomer")
	public Customer AddCustomer(@RequestBody Customer customer) {
		
		return this.customerService.AddCustomer(customer);
	}
	@GetMapping("customer/{id}")
	public Customer getCustomerById(@PathVariable String id) throws CustomerException {
		return this.customerService.getCustomerById(id);
	}
	@DeleteMapping("deletecustomer/{id}")
	public Customer deleteCustomer(@PathVariable("id")String customerId) throws CustomerException {
		return this.customerService.deleteCustomerById(customerId);
	}
	
}


