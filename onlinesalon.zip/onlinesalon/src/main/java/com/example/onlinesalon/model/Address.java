package com.example.onlinesalon.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Address {
	 String doorNo;
	 String street;
	 String area;
     String city;
	 String state;
	 int pincode;
	
	public Address(String area, String city, String state, int pincode, String street,
		 String doorNo) {
			super();
			this.doorNo=doorNo;
			this.street=street;
			this.area=area;
			this.city=city;
			this.state=state;
			this.pincode=pincode;

}


	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getdoorNo() {
    	 return doorNo;
     }
     public void setdoorNo(String doorNo) {
    	 this.doorNo=doorNo;
     }
     public String street() {
    	 return street;
     }
     public void setstreet(String street) {
    	 this.street=street;
     }
     public String area() {
    	 return area;
     }
     public void setarea(String area) {
    	 this.area=area;
     }
     public String city() {
    	 return city;
     }
     public void setcity(String city) {
    	 this.city=city;
     }
     public String state() {
    	 return state;
     }
     public void setstate(String state) {
    	 this.state=state;
     }
     public Integer pincode() {
    	 return pincode;
     }
     public void setpincode(Integer pincode) {
    	 this.pincode=pincode;
     }
  }

