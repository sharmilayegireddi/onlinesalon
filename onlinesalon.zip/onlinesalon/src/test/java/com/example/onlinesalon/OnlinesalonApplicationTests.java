package com.example.onlinesalon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinesalonApplicationTests {

	@Test
	void contextLoads() {
	}

}
